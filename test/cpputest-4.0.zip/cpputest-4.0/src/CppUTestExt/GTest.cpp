
#include "CppUTest/TestHarness.h"
#include "CppUTestExt/GTestSupport.h"

void CppuTestGTestIgnoreLeaksInTest()
{
    IGNORE_ALL_LEAKS_IN_TEST();
}

