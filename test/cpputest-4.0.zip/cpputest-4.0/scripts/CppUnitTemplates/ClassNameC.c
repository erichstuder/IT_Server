#include "ClassName.h"
#include <stdlib.h>
#include <memory.h>

//static local variables


void ClassName_Create(void)
{
}

void ClassName_Destroy(void)
{
}


