**Intro**
The CppUTest_VS2010.props property sheet sets the needed compiler and linker options for your unit test project.

**Instructions**
1) Create a system environment variable, CPPUTEST_HOME and set it to the path of your CppUTest distribution.
2) Add the CppUTest_VS2010.props property sheet to your unit test project and you are good to go.
3) See the WalkThrough_VS2010 guide in the docs section for details. 

