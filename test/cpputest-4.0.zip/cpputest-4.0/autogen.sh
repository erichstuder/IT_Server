#!/bin/sh
#
# cpputest autogen.sh
#
# Run this to generate all the initial makefiles, etc.

autoreconf -i
